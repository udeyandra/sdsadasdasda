export const loadImage = imageName => {
  return require(`../../images/${imageName}`);
};