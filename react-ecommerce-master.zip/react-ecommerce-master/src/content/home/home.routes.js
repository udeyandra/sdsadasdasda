import Home from './home';

export default [
  {
    'path': '/',
    'component': Home
  }
]