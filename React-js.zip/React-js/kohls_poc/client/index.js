import React from 'react';
import ReactDom from 'react-dom';
import Popup from 'react-popup';
require('./css/style.css');
require('./js/bootstrap.min.js');
import App from './components/App.jsx';
var AppConfig = ReactDom.render( <App /> ,
    document.getElementById('maincontainer')
);
/** Call the plugin */
Popup.plugins().prompt('', 'Type your name', function(value) {
    Popup.alert('You typed: ' + value);
});
module.exports = appConfig;