$(document).ready(function() {
    $(".close").on("click", function() {
        $(".popup").hide();
        alert(1);
    });
});