import React from 'react';
import ReactDom from 'react-dom';
import Popup from 'react-popup';
import Header from './Header.jsx';
import Content from './Content.jsx';
/** The prompt content component */
class Prompt extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            value: this.props.defaultValue
        };

        this.onChange = (e) => this._onChange(e);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.value !== this.state.value) {
            this.props.onChange(this.state.value);
        }
    }

    _onChange(e) {
        let value = e.target.value;

        this.setState({ value: value });
    }

    render() {
        return;
    }
}

/** Prompt plugin */
Popup.registerPlugin('prompt', function(defaultValue, placeholder, callback) {
    let promptValue = "";
    let promptChange = function(value) {
        promptValue = value;
    };

    this.create({
        title: 'What\'s your name?',
        content: '',
        buttons: {
            left: ['cancel'],
            right: [{
                text: 'Save',
                className: 'success',
                action: function() {
                    callback(promptValue);
                    Popup.close();
                }
            }]
        }
    });
});
class App extends React.Component {
 

   render() {
      return ( <div>
	   <Popup
    className="mm-popup"
    btnClass="mm-popup__btn"
    closeBtn={true}
    closeHtml={null}
    defaultOk="Ok"
    defaultCancel="Cancel"
    wildClasses={false}
    closeOnOutsideClick={true} />
            <Header/>
            <Content/>
         </div>
      );
   }
}
module.exports = App