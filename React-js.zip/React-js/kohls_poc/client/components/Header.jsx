import React from 'react';
import ReactDom from 'react-dom';
import Popup from 'react-popup';
class Header extends React.Component {
	
   render() {
      return (
         <div className="container-fluid padding-left-right-0">
         <div className="row">
           <div className="col-xs-12 col-md-12 col-lg-12 equity-bar">
           <div className="container">
           <div className="new-dc-equity-banner">
            <div className="col-xs-12 col-md-5 col-lg-5">
            <a href="https://www.kohls.com/ecom/shipping/75_ShippingUPDATED_nodates_bopus.html" target="_blank" className="dcp-banner-left"><b>FREE</b> standard shipping with $75 purchase <span>details</span></a>
            </div>
            <div className="col-xs-12 col-md-3 col-lg-3">
            <a href="/catalog.jsp?CN=InStoreOnline:Pick%20Up%20in%20Store&amp;BL=y" className="dcp-banner-center notification-hide-banner"><b>FREE</b> store pickup today</a>
            </div>
            <div className="col-xs-12 col-md-4 col-lg-4">
            <a href="https://www.kohls.com/ecom/Kcash/5KohlsCash_REDEEM.html" target="_blank" className="dcp-banner-right notification-hide-banner"><b>R&#8203;EDEEM</b> your Kohl's Cash&#8203;® now <span>details</span></a>
            </div>
           </div>
           <div className="navbar-form navbar-left" id="persistent_bar_container">
            <div className="navbar-brand">
                <img src="./client/media/images/global-header-refresh-icons/kohls-logo.png" />
            </div>
            <form action="/search.jsp" method="get" className="navbar-form navbar-left form-width" id="site-search">
              <div className="col-xs-12 col-md-12 col-lg-12">
                <input type="text" className="form-control typeaheadSearch" name="search" id="search" />
              </div>
            </form>
            <div className="utility-nav">
            <ul className="right-nav">
                <li className="utility-greeting">
                <a href="#" className="utility-item-link account utility-nav-wallet-svg">
                <img  src="./client/media/images/global-header-refresh-icons/account-icon.svg" /> 
                Account
                </a>
               </li>
               <li className="utility-greeting">
                <a href="#" className="utility-item-link account utility-nav-wallet-svg">
                <img  src="./client/media/images/global-header-refresh-icons/bag-icon.svg" /> 
                <span className="subTotal">$0.00</span>
                </a>
               </li>
               <li className="utility-greeting">
                <a href="#" className="utility-item-link account utility-nav-wallet-svg">
                <img  src="./client/media/images/global-header-refresh-icons/check-out-icon.png" /> 
                <span>Account</span>
                </a>
               </li>
            </ul>
            </div>
           </div>
           </div>
           </div>
         </div>
         </div>
      );
   }
}
module.exports = Header;