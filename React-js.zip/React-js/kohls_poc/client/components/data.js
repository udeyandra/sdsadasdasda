
var pmpSearchJsonData = {
	"environment": "production",
	"currentDate": "7/15/2017, 06:25:07 PM",
	"status": {
		"code": "200"
	},
	"totalRecordsCount": 1729,
	"totalPages": 29,
	"pageType": "search",
	"pageName": "search",
	"pageSeoURL": "/search.jsp?N=0&search=shirts",
	"source": "solr",
	"src": "e2",
	"PInfo": {
		"resultPData": false
	},
	"searchTerm": "shirts",
	"relatedSearchTerms": [{
		"link": "/search.jsp?submit-search=web-regular&search=mens+shirts&related=true",
		"anchor": "mens shirts"
	}],
	"searchMsg": "Search Results for <strong>\"shirts\"</strong>",
	"guidedNavInfo": {
		"breadcrumbList": [{
			"name": "All Products",
			"URL": "/catalog.jsp"
		}],
		"visualNavInfo": {
			"title": "Shop Shirts",
			"visualNavs": [{
				"linkURL": "/catalog/mens-tops-tees-tops-clothing.jsp?CN=Gender:Mens+Product:Tops%20%26%20Tees+Category:Tops+Department:Clothing&icid=genshirts-VN1-mens",
				"label": "Mens",
				"imageURL": "//media.kohlsimg.com/is/image/kohls/2678166_Purple_Raisin"
			}, {
				"linkURL": "/catalog/womens-tops-tees-tops-clothing.jsp?CN=Gender:Womens+Product:Tops%20%26%20Tees+Category:Tops+Department:Clothing&icid=genshirts-VN2-womens",
				"label": "Womens",
				"imageURL": "//media.kohlsimg.com/is/image/kohls/2553175_Decadent_Chocolate"
			}, {
				"linkURL": "/catalog/mens-dress-shirts-tops-clothing.jsp?CN=Gender:Mens+Silhouette:Dress%20Shirts+Category:Tops+Department:Clothing&icid=genshirts-VN3-dressshirts",
				"label": "Dress Shirts",
				"imageURL": "//media.kohlsimg.com/is/image/kohls/2344535_Navy_Gingham"
			}, {
				"linkURL": "/catalog/polos-tops-tees-tops-clothing.jsp?CN=Silhouette:Polos+Product:Tops%20%26%20Tees+Category:Tops+Department:Clothing&icid=genshirts-VN4-polos",
				"label": "Polos",
				"imageURL": "//media1.kohlsimg.com/is/image/kohls/1373162_Pebble_Heather"
			}, {
				"linkURL": "/catalog/t-shirts-tops-tees-tops-clothing.jsp?CN=Silhouette:T-Shirts+Product:Tops%20%26%20Tees+Category:Tops+Department:Clothing&icid=genshirts-VN5-tshirts",
				"label": "T-Shirts",
				"imageURL": "//media1.kohlsimg.com/is/image/kohls/2466260_Navy"
			}]
		},
		"dimensionList": [{
			"dimension": "Store Availability",
			"facets": [{
				"productCount": 1658,
				"isSelected": false,
				"name": "Online Only",
				"URL": "/search.jsp?CN=InStoreOnline:Online%20Only&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 76,
				"isSelected": false,
				"name": "Pick Up in Store",
				"URL": "/search.jsp?CN=InStoreOnline:Pick%20Up%20in%20Store&BL=y&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "InStoreOnline"
		}, {
			"dimension": "Department",
			"facets": [{
				"productCount": 4,
				"isSelected": false,
				"name": "Accessories",
				"URL": "/search/accessories.jsp?CN=Department:Accessories&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Baby Gear",
				"URL": "/search/baby-gear.jsp?CN=Department:Baby%20Gear&search=shirts&S=1&WS=0"
			}, {
				"productCount": 17,
				"isSelected": false,
				"name": "Bed & Bath",
				"URL": "/search/bed-bath.jsp?CN=Department:Bed%20%26%20Bath&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1494,
				"isSelected": false,
				"name": "Clothing",
				"URL": "/search/clothing.jsp?CN=Department:Clothing&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Furniture & Decor",
				"URL": "/search/furniture-decor.jsp?CN=Department:Furniture%20%26%20Decor&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Health & Beauty",
				"URL": "/search/health-beauty.jsp?CN=Department:Health%20%26%20Beauty&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Patio & Garden",
				"URL": "/search/patio-garden.jsp?CN=Department:Patio%20%26%20Garden&search=shirts&S=1&WS=0"
			}, {
				"productCount": 17,
				"isSelected": false,
				"name": "Shoes",
				"URL": "/search/shoes.jsp?CN=Department:Shoes&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "Sports & Fitness",
				"URL": "/search/sports-fitness.jsp?CN=Department:Sports%20%26%20Fitness&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Toys",
				"URL": "/search/toys.jsp?CN=Department:Toys&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "Cloth",
				"URL": "/search/cloth.jsp?CN=Department:Cloth&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Department"
		}, {
			"dimension": "Gender",
			"facets": [{
				"productCount": 289,
				"isSelected": false,
				"name": "Womens",
				"URL": "/search/womens.jsp?CN=Gender:Womens&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1044,
				"isSelected": false,
				"name": "Mens",
				"URL": "/search/mens.jsp?CN=Gender:Mens&search=shirts&S=1&WS=0"
			}, {
				"productCount": 65,
				"isSelected": false,
				"name": "Juniors",
				"URL": "/search/juniors.jsp?CN=Gender:Juniors&search=shirts&S=1&WS=0"
			}, {
				"productCount": 96,
				"isSelected": false,
				"name": "Teen Guys",
				"URL": "/search/teen-guys.jsp?CN=Gender:Teen%20Guys&search=shirts&S=1&WS=0"
			}, {
				"productCount": 102,
				"isSelected": false,
				"name": "Girls",
				"URL": "/search/girls.jsp?CN=Gender:Girls&search=shirts&S=1&WS=0"
			}, {
				"productCount": 152,
				"isSelected": false,
				"name": "Boys",
				"URL": "/search/boys.jsp?CN=Gender:Boys&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Neutral",
				"URL": "/search/neutral.jsp?CN=Gender:Neutral&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Female",
				"URL": "/search/female.jsp?CN=Gender:Female&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Male",
				"URL": "/search/male.jsp?CN=Gender:Male&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Gender"
		}, {
			"dimension": "Size Range",
			"facets": [{
				"productCount": 212,
				"isSelected": false,
				"name": "Big & Tall",
				"URL": "/search/big-tall.jsp?CN=SizeRange:Big%20%26%20Tall&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Extra Wide",
				"URL": "/search/extra-wide.jsp?CN=SizeRange:Extra%20Wide&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Husky",
				"URL": "/search/husky.jsp?CN=SizeRange:Husky&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Narrow",
				"URL": "/search/narrow.jsp?CN=SizeRange:Narrow&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Petite",
				"URL": "/search/petite.jsp?CN=SizeRange:Petite&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Petitie",
				"URL": "/search/petitie.jsp?CN=SizeRange:Petitie&search=shirts&S=1&WS=0"
			}, {
				"productCount": 42,
				"isSelected": false,
				"name": "Plus",
				"URL": "/search/plus.jsp?CN=SizeRange:Plus&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1398,
				"isSelected": false,
				"name": "Regular",
				"URL": "/search/regular.jsp?CN=SizeRange:Regular&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Tall",
				"URL": "/search/tall.jsp?CN=SizeRange:Tall&search=shirts&S=1&WS=0"
			}, {
				"productCount": 53,
				"isSelected": false,
				"name": "Unassigned",
				"URL": "/search/unassigned.jsp?CN=SizeRange:Unassigned&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "SizeRange"
		}, {
			"dimension": "Size",
			"facets": [{
				"productCount": 11,
				"isSelected": false,
				"name": "KING",
				"URL": "/search.jsp?CN=Size:KING&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 18,
				"isSelected": false,
				"name": "QUEEN",
				"URL": "/search.jsp?CN=Size:QUEEN&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "FULL",
				"URL": "/search.jsp?CN=Size:FULL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 16,
				"isSelected": false,
				"name": "TWIN",
				"URL": "/search.jsp?CN=Size:TWIN&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "TWIN XL",
				"URL": "/search.jsp?CN=Size:TWIN%20XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "CALIFORNIA KING",
				"URL": "/search.jsp?CN=Size:CALIFORNIA%20KING&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "0-3 Months",
				"URL": "/search.jsp?CN=Size:0-3%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "3-6 Months",
				"URL": "/search.jsp?CN=Size:3-6%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "6-9 Months",
				"URL": "/search.jsp?CN=Size:6-9%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "9-12 Months",
				"URL": "/search.jsp?CN=Size:9-12%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "12-18 Months",
				"URL": "/search.jsp?CN=Size:12-18%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "18-24 Months",
				"URL": "/search.jsp?CN=Size:18-24%20Months&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 38,
				"isSelected": false,
				"name": "XS",
				"URL": "/search.jsp?CN=Size:XS&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 270,
				"isSelected": false,
				"name": "S",
				"URL": "/search.jsp?CN=Size:S&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 327,
				"isSelected": false,
				"name": "M",
				"URL": "/search.jsp?CN=Size:M&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 339,
				"isSelected": false,
				"name": "L",
				"URL": "/search.jsp?CN=Size:L&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 313,
				"isSelected": false,
				"name": "XL",
				"URL": "/search.jsp?CN=Size:XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 269,
				"isSelected": false,
				"name": "2XL",
				"URL": "/search.jsp?CN=Size:2XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 37,
				"isSelected": false,
				"name": "3XL",
				"URL": "/search.jsp?CN=Size:3XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 32,
				"isSelected": false,
				"name": "4XL",
				"URL": "/search.jsp?CN=Size:4XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "5XL",
				"URL": "/search.jsp?CN=Size:5XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "6XL",
				"URL": "/search.jsp?CN=Size:6XL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "1X",
				"URL": "/search.jsp?CN=Size:1X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 13,
				"isSelected": false,
				"name": "2X",
				"URL": "/search.jsp?CN=Size:2X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "3X",
				"URL": "/search.jsp?CN=Size:3X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "4X",
				"URL": "/search.jsp?CN=Size:4X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "MT",
				"URL": "/search.jsp?CN=Size:MT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 27,
				"isSelected": false,
				"name": "LT",
				"URL": "/search.jsp?CN=Size:LT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 46,
				"isSelected": false,
				"name": "XLT",
				"URL": "/search.jsp?CN=Size:XLT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 36,
				"isSelected": false,
				"name": "2XLT",
				"URL": "/search.jsp?CN=Size:2XLT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 48,
				"isSelected": false,
				"name": "3XLT",
				"URL": "/search.jsp?CN=Size:3XLT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "4XLT",
				"URL": "/search.jsp?CN=Size:4XLT&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "SP",
				"URL": "/search.jsp?CN=Size:SP&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "LP",
				"URL": "/search.jsp?CN=Size:LP&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "XLP",
				"URL": "/search.jsp?CN=Size:XLP&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "0",
				"URL": "/search.jsp?CN=Size:0&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "2",
				"URL": "/search.jsp?CN=Size:2&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 33,
				"isSelected": false,
				"name": "4",
				"URL": "/search.jsp?CN=Size:4&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 29,
				"isSelected": false,
				"name": "5",
				"URL": "/search.jsp?CN=Size:5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 31,
				"isSelected": false,
				"name": "6",
				"URL": "/search.jsp?CN=Size:6&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 43,
				"isSelected": false,
				"name": "7",
				"URL": "/search.jsp?CN=Size:7&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "7.5",
				"URL": "/search.jsp?CN=Size:7.5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 55,
				"isSelected": false,
				"name": "8",
				"URL": "/search.jsp?CN=Size:8&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "8.5",
				"URL": "/search.jsp?CN=Size:8.5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "9",
				"URL": "/search.jsp?CN=Size:9&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "9.5",
				"URL": "/search.jsp?CN=Size:9.5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 55,
				"isSelected": false,
				"name": "10",
				"URL": "/search.jsp?CN=Size:10&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "10.5",
				"URL": "/search.jsp?CN=Size:10.5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "11",
				"URL": "/search.jsp?CN=Size:11&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 53,
				"isSelected": false,
				"name": "12",
				"URL": "/search.jsp?CN=Size:12&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "13",
				"URL": "/search.jsp?CN=Size:13&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 52,
				"isSelected": false,
				"name": "14",
				"URL": "/search.jsp?CN=Size:14&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 62,
				"isSelected": false,
				"name": "16",
				"URL": "/search.jsp?CN=Size:16&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 29,
				"isSelected": false,
				"name": "18",
				"URL": "/search.jsp?CN=Size:18&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 30,
				"isSelected": false,
				"name": "20",
				"URL": "/search.jsp?CN=Size:20&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "2T",
				"URL": "/search.jsp?CN=Size:2T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 18,
				"isSelected": false,
				"name": "3T",
				"URL": "/search.jsp?CN=Size:3T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "4T",
				"URL": "/search.jsp?CN=Size:4T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "7T",
				"URL": "/search.jsp?CN=Size:7T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "9T",
				"URL": "/search.jsp?CN=Size:9T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "11T",
				"URL": "/search.jsp?CN=Size:11T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "12Y",
				"URL": "/search.jsp?CN=Size:12Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "13Y",
				"URL": "/search.jsp?CN=Size:13Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "1Y",
				"URL": "/search.jsp?CN=Size:1Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "2Y",
				"URL": "/search.jsp?CN=Size:2Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "3Y",
				"URL": "/search.jsp?CN=Size:3Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "3.5Y",
				"URL": "/search.jsp?CN=Size:3.5Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "4Y",
				"URL": "/search.jsp?CN=Size:4Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "5Y",
				"URL": "/search.jsp?CN=Size:5Y&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "12 1/2",
				"URL": "/search.jsp?CN=Size:12%201%7E2&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "12P",
				"URL": "/search.jsp?CN=Size:12P&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "14.5 32/33",
				"URL": "/search.jsp?CN=Size:14.5%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "15 32/33",
				"URL": "/search.jsp?CN=Size:15%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "15 34/35",
				"URL": "/search.jsp?CN=Size:15%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 17,
				"isSelected": false,
				"name": "15.5 32/33",
				"URL": "/search.jsp?CN=Size:15.5%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "15.5 34/35",
				"URL": "/search.jsp?CN=Size:15.5%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "16 32/33",
				"URL": "/search.jsp?CN=Size:16%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 21,
				"isSelected": false,
				"name": "16 34/35",
				"URL": "/search.jsp?CN=Size:16%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "16.5 32/33",
				"URL": "/search.jsp?CN=Size:16.5%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "16.5 34/35",
				"URL": "/search.jsp?CN=Size:16.5%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 18,
				"isSelected": false,
				"name": "16.5 36/37",
				"URL": "/search.jsp?CN=Size:16.5%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "16W",
				"URL": "/search.jsp?CN=Size:16W&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "17 32/33",
				"URL": "/search.jsp?CN=Size:17%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "17 34/35",
				"URL": "/search.jsp?CN=Size:17%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 17,
				"isSelected": false,
				"name": "17 36/37",
				"URL": "/search.jsp?CN=Size:17%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 13,
				"isSelected": false,
				"name": "17.5 32/33",
				"URL": "/search.jsp?CN=Size:17.5%2032%7E33&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "17.5 34/35",
				"URL": "/search.jsp?CN=Size:17.5%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 19,
				"isSelected": false,
				"name": "17.5 36/37",
				"URL": "/search.jsp?CN=Size:17.5%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "17X24",
				"URL": "/search.jsp?CN=Size:17X24&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "18 34/35",
				"URL": "/search.jsp?CN=Size:18%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "18 36/37",
				"URL": "/search.jsp?CN=Size:18%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "18.5 34/35",
				"URL": "/search.jsp?CN=Size:18.5%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "18.5 36/37",
				"URL": "/search.jsp?CN=Size:18.5%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "18.5 38/39",
				"URL": "/search.jsp?CN=Size:18.5%2038%7E39&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "19 36/37",
				"URL": "/search.jsp?CN=Size:19%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "19 38/39",
				"URL": "/search.jsp?CN=Size:19%2038%7E39&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "20 1/2",
				"URL": "/search.jsp?CN=Size:20%201%7E2&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "20 34/35",
				"URL": "/search.jsp?CN=Size:20%2034%7E35&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "20 36/37",
				"URL": "/search.jsp?CN=Size:20%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "20X32",
				"URL": "/search.jsp?CN=Size:20X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "22T",
				"URL": "/search.jsp?CN=Size:22T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "24W",
				"URL": "/search.jsp?CN=Size:24W&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "2XB",
				"URL": "/search.jsp?CN=Size:2XB&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "30A",
				"URL": "/search.jsp?CN=Size:30A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "30B",
				"URL": "/search.jsp?CN=Size:30B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "30C",
				"URL": "/search.jsp?CN=Size:30C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "30D",
				"URL": "/search.jsp?CN=Size:30D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "32",
				"URL": "/search.jsp?CN=Size:32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "32A",
				"URL": "/search.jsp?CN=Size:32A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32AA",
				"URL": "/search.jsp?CN=Size:32AA&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32B",
				"URL": "/search.jsp?CN=Size:32B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32C",
				"URL": "/search.jsp?CN=Size:32C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "32D",
				"URL": "/search.jsp?CN=Size:32D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "32DD",
				"URL": "/search.jsp?CN=Size:32DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32X30",
				"URL": "/search.jsp?CN=Size:32X30&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32X32",
				"URL": "/search.jsp?CN=Size:32X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "32X34",
				"URL": "/search.jsp?CN=Size:32X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "34A",
				"URL": "/search.jsp?CN=Size:34A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "34B",
				"URL": "/search.jsp?CN=Size:34B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "34C",
				"URL": "/search.jsp?CN=Size:34C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "34D",
				"URL": "/search.jsp?CN=Size:34D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "34DD",
				"URL": "/search.jsp?CN=Size:34DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "34X29",
				"URL": "/search.jsp?CN=Size:34X29&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "34X34",
				"URL": "/search.jsp?CN=Size:34X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "36",
				"URL": "/search.jsp?CN=Size:36&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "36A",
				"URL": "/search.jsp?CN=Size:36A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "36B",
				"URL": "/search.jsp?CN=Size:36B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "36C",
				"URL": "/search.jsp?CN=Size:36C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "36D",
				"URL": "/search.jsp?CN=Size:36D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "36DD",
				"URL": "/search.jsp?CN=Size:36DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "36X29",
				"URL": "/search.jsp?CN=Size:36X29&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "36X30",
				"URL": "/search.jsp?CN=Size:36X30&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "36X34",
				"URL": "/search.jsp?CN=Size:36X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "38",
				"URL": "/search.jsp?CN=Size:38&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "38A",
				"URL": "/search.jsp?CN=Size:38A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "38B",
				"URL": "/search.jsp?CN=Size:38B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "38C",
				"URL": "/search.jsp?CN=Size:38C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "38D",
				"URL": "/search.jsp?CN=Size:38D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "38DD",
				"URL": "/search.jsp?CN=Size:38DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "38F",
				"URL": "/search.jsp?CN=Size:38F&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "38S",
				"URL": "/search.jsp?CN=Size:38S&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "38X29",
				"URL": "/search.jsp?CN=Size:38X29&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "38X30",
				"URL": "/search.jsp?CN=Size:38X30&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "38X34",
				"URL": "/search.jsp?CN=Size:38X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "3XB",
				"URL": "/search.jsp?CN=Size:3XB&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 23,
				"isSelected": false,
				"name": "40",
				"URL": "/search.jsp?CN=Size:40&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "40A",
				"URL": "/search.jsp?CN=Size:40A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "40B",
				"URL": "/search.jsp?CN=Size:40B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "40C",
				"URL": "/search.jsp?CN=Size:40C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "40D",
				"URL": "/search.jsp?CN=Size:40D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "40DD",
				"URL": "/search.jsp?CN=Size:40DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "40S",
				"URL": "/search.jsp?CN=Size:40S&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "40T",
				"URL": "/search.jsp?CN=Size:40T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "40X32",
				"URL": "/search.jsp?CN=Size:40X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "40X34",
				"URL": "/search.jsp?CN=Size:40X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 16,
				"isSelected": false,
				"name": "42",
				"URL": "/search.jsp?CN=Size:42&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "42A",
				"URL": "/search.jsp?CN=Size:42A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "42B",
				"URL": "/search.jsp?CN=Size:42B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "42C",
				"URL": "/search.jsp?CN=Size:42C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "42D",
				"URL": "/search.jsp?CN=Size:42D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "42DD",
				"URL": "/search.jsp?CN=Size:42DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "42F",
				"URL": "/search.jsp?CN=Size:42F&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "42S",
				"URL": "/search.jsp?CN=Size:42S&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "42T",
				"URL": "/search.jsp?CN=Size:42T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "42X29",
				"URL": "/search.jsp?CN=Size:42X29&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "42X30",
				"URL": "/search.jsp?CN=Size:42X30&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 16,
				"isSelected": false,
				"name": "44",
				"URL": "/search.jsp?CN=Size:44&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "44A",
				"URL": "/search.jsp?CN=Size:44A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "44B",
				"URL": "/search.jsp?CN=Size:44B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "44D",
				"URL": "/search.jsp?CN=Size:44D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "44S",
				"URL": "/search.jsp?CN=Size:44S&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 19,
				"isSelected": false,
				"name": "44T",
				"URL": "/search.jsp?CN=Size:44T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "44X32",
				"URL": "/search.jsp?CN=Size:44X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "44X34",
				"URL": "/search.jsp?CN=Size:44X34&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 18,
				"isSelected": false,
				"name": "46",
				"URL": "/search.jsp?CN=Size:46&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46A",
				"URL": "/search.jsp?CN=Size:46A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46B",
				"URL": "/search.jsp?CN=Size:46B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46C",
				"URL": "/search.jsp?CN=Size:46C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46DD",
				"URL": "/search.jsp?CN=Size:46DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 14,
				"isSelected": false,
				"name": "46T",
				"URL": "/search.jsp?CN=Size:46T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46X29",
				"URL": "/search.jsp?CN=Size:46X29&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "46X30",
				"URL": "/search.jsp?CN=Size:46X30&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "48",
				"URL": "/search.jsp?CN=Size:48&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "48D",
				"URL": "/search.jsp?CN=Size:48D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "48DD",
				"URL": "/search.jsp?CN=Size:48DD&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "48T",
				"URL": "/search.jsp?CN=Size:48T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "48X32",
				"URL": "/search.jsp?CN=Size:48X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "4XB",
				"URL": "/search.jsp?CN=Size:4XB&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "50",
				"URL": "/search.jsp?CN=Size:50&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "50A",
				"URL": "/search.jsp?CN=Size:50A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "50T",
				"URL": "/search.jsp?CN=Size:50T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "50X32",
				"URL": "/search.jsp?CN=Size:50X32&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "52",
				"URL": "/search.jsp?CN=Size:52&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "52T",
				"URL": "/search.jsp?CN=Size:52T&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "52X95",
				"URL": "/search.jsp?CN=Size:52X95&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "54",
				"URL": "/search.jsp?CN=Size:54&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "56",
				"URL": "/search.jsp?CN=Size:56&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "6X",
				"URL": "/search.jsp?CN=Size:6X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "7X",
				"URL": "/search.jsp?CN=Size:7X&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "A",
				"URL": "/search.jsp?CN=Size:A&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "B",
				"URL": "/search.jsp?CN=Size:B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "C",
				"URL": "/search.jsp?CN=Size:C&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "D",
				"URL": "/search.jsp?CN=Size:D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "E",
				"URL": "/search.jsp?CN=Size:E&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "F",
				"URL": "/search.jsp?CN=Size:F&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "LARGE",
				"URL": "/search.jsp?CN=Size:LARGE&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "MEDIUM",
				"URL": "/search.jsp?CN=Size:MEDIUM&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "SMALL",
				"URL": "/search.jsp?CN=Size:SMALL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "X LARGE",
				"URL": "/search.jsp?CN=Size:X%20LARGE&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "X SMALL",
				"URL": "/search.jsp?CN=Size:X%20SMALL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "XX SMALL",
				"URL": "/search.jsp?CN=Size:XX%20SMALL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "XXL",
				"URL": "/search.jsp?CN=Size:XXL&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "16 36/37",
				"URL": "/search.jsp?CN=Size:16%2036%7E37&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "12 HUSKY",
				"URL": "/search.jsp?CN=Size:12%20HUSKY&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "14 HUSKY",
				"URL": "/search.jsp?CN=Size:14%20HUSKY&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "46 X-LONG",
				"URL": "/search.jsp?CN=Size:46%20X-LONG&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "A-B",
				"URL": "/search.jsp?CN=Size:A-B&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "C-D",
				"URL": "/search.jsp?CN=Size:C-D&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "E-F",
				"URL": "/search.jsp?CN=Size:E-F&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "G-H",
				"URL": "/search.jsp?CN=Size:G-H&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "I-J",
				"URL": "/search.jsp?CN=Size:I-J&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "LH",
				"URL": "/search.jsp?CN=Size:LH&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "MEDIUM 3",
				"URL": "/search.jsp?CN=Size:MEDIUM%203&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "MH",
				"URL": "/search.jsp?CN=Size:MH&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "XLH",
				"URL": "/search.jsp?CN=Size:XLH&BL=y&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Size"
		}, {
			"dimension": "Sleeve Length",
			"facets": [{
				"productCount": 583,
				"isSelected": false,
				"name": "Long Sleeve",
				"URL": "/search/long-sleeve.jsp?CN=SleeveLength:Long%20Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 22,
				"isSelected": false,
				"name": "3/4 Sleeve",
				"URL": "/search/34-sleeve.jsp?CN=SleeveLength:3%7E4%20Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 630,
				"isSelected": false,
				"name": "Short Sleeve",
				"URL": "/search/short-sleeve.jsp?CN=SleeveLength:Short%20Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 62,
				"isSelected": false,
				"name": "Sleeveless",
				"URL": "/search/sleeveless.jsp?CN=SleeveLength:Sleeveless&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Strapless",
				"URL": "/search/strapless.jsp?CN=SleeveLength:Strapless&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Elbow Sleeve",
				"URL": "/search/elbow-sleeve.jsp?CN=SleeveLength:Elbow%20Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 113,
				"isSelected": false,
				"name": "Short-Sleeve",
				"URL": "/search/shortsleeve.jsp?CN=SleeveLength:Short-Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 62,
				"isSelected": false,
				"name": "Long-Sleeve",
				"URL": "/search/longsleeve.jsp?CN=SleeveLength:Long-Sleeve&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "3/4-Sleeve",
				"URL": "/search/34sleeve.jsp?CN=SleeveLength:3%7E4-Sleeve&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "SleeveLength"
		}, {
			"dimension": "Brand",
			"facets": [{
				"productCount": 4,
				"isSelected": false,
				"name": "212 Collection",
				"URL": "/search/212-collection.jsp?CN=Brand:212%20Collection&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "AB Studio",
				"URL": "/search/ab-studio.jsp?CN=Brand:AB%20Studio&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "About A Girl",
				"URL": "/search/about-a-girl.jsp?CN=Brand:About%20A%20Girl&search=shirts&S=1&WS=0"
			}, {
				"productCount": 68,
				"isSelected": false,
				"name": "adidas",
				"URL": "/search/adidas.jsp?CN=Brand:adidas&search=shirts&S=1&WS=0"
			}, {
				"productCount": 51,
				"isSelected": false,
				"name": "Antigua",
				"URL": "/search/antigua.jsp?CN=Brand:Antigua&search=shirts&S=1&WS=0"
			}, {
				"productCount": 41,
				"isSelected": false,
				"name": "Apt. 9",
				"URL": "/search/apt-9.jsp?CN=Brand:Apt.%209&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "Arrow",
				"URL": "/search/arrow.jsp?CN=Brand:Arrow&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "ASICS",
				"URL": "/search/asics.jsp?CN=Brand:ASICS&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "axcess",
				"URL": "/search/axcess.jsp?CN=Brand:axcess&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Axist",
				"URL": "/search/axist.jsp?CN=Brand:Axist&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "Bali",
				"URL": "/search/bali.jsp?CN=Brand:Bali&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "barely there",
				"URL": "/search/barely-there.jsp?CN=Brand:barely%20there&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Bates",
				"URL": "/search/bates.jsp?CN=Brand:Bates&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Billy London",
				"URL": "/search/billy-london.jsp?CN=Brand:Billy%20London&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Boon",
				"URL": "/search/boon.jsp?CN=Brand:Boon&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Bucco",
				"URL": "/search/bucco.jsp?CN=Brand:Bucco&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Burt's Bees Baby",
				"URL": "/search/burts-bees-baby.jsp?CN=Brand:Burt%27s%20Bees%20Baby&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Candie's",
				"URL": "/search/candies.jsp?CN=Brand:Candie%27s&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Cardinal",
				"URL": "/search/cardinal.jsp?CN=Brand:Cardinal&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "Carter's",
				"URL": "/search/carters.jsp?CN=Brand:Carter%27s&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Catherine Malandrino for DesigNation",
				"URL": "/search/catherine-malandrino-for-designation.jsp?CN=Brand:Catherine%20Malandrino%20for%20DesigNation&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Cathy Daniels",
				"URL": "/search/cathy-daniels.jsp?CN=Brand:Cathy%20Daniels&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Centro",
				"URL": "/search/centro.jsp?CN=Brand:Centro&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Champion",
				"URL": "/search/champion.jsp?CN=Brand:Champion&search=shirts&S=1&WS=0"
			}, {
				"productCount": 72,
				"isSelected": false,
				"name": "Chaps",
				"URL": "/search/chaps.jsp?CN=Brand:Chaps&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Chicka-d",
				"URL": "/search/chickad.jsp?CN=Brand:Chicka-d&search=shirts&S=1&WS=0"
			}, {
				"productCount": 36,
				"isSelected": false,
				"name": "Colosseum",
				"URL": "/search/colosseum.jsp?CN=Brand:Colosseum&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "Columbia",
				"URL": "/search/columbia.jsp?CN=Brand:Columbia&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Converse",
				"URL": "/search/converse.jsp?CN=Brand:Converse&search=shirts&S=1&WS=0"
			}, {
				"productCount": 124,
				"isSelected": false,
				"name": "Croft & Barrow",
				"URL": "/search/croft-barrow.jsp?CN=Brand:Croft%20%26%20Barrow&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Cuddl Duds",
				"URL": "/search/cuddl-duds.jsp?CN=Brand:Cuddl%20Duds&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "daisy fuentes",
				"URL": "/search/daisy-fuentes.jsp?CN=Brand:daisy%20fuentes&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Dana Buchman",
				"URL": "/search/dana-buchman.jsp?CN=Brand:Dana%20Buchman&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "DC Shoe Co",
				"URL": "/search/dc-shoe-co.jsp?CN=Brand:DC%20Shoe%20Co&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Derek Heart",
				"URL": "/search/derek-heart.jsp?CN=Brand:Derek%20Heart&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Derek Lam for DesigNation",
				"URL": "/search/derek-lam-for-designation.jsp?CN=Brand:Derek%20Lam%20for%20DesigNation&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Design 365",
				"URL": "/search/design-365.jsp?CN=Brand:Design%20365&search=shirts&S=1&WS=0"
			}, {
				"productCount": 20,
				"isSelected": false,
				"name": "Dickies",
				"URL": "/search/dickies.jsp?CN=Brand:Dickies&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "Disney",
				"URL": "/search/disney.jsp?CN=Brand:Disney&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Disney/Jumping Beans",
				"URL": "/search/disneyjumping-beans.jsp?CN=Brand:Disney%7EJumping%20Beans&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Distortion",
				"URL": "/search/distortion.jsp?CN=Brand:Distortion&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "Dockers",
				"URL": "/search/dockers.jsp?CN=Brand:Dockers&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Dream Therapy",
				"URL": "/search/dream-therapy.jsp?CN=Brand:Dream%20Therapy&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Dyse One",
				"URL": "/search/dyse-one.jsp?CN=Brand:Dyse%20One&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "ELLE",
				"URL": "/search/elle.jsp?CN=Brand:ELLE&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Energie",
				"URL": "/search/energie.jsp?CN=Brand:Energie&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "essie",
				"URL": "/search/essie.jsp?CN=Brand:essie&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Eyelash",
				"URL": "/search/eyelash.jsp?CN=Brand:Eyelash&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Faux Real",
				"URL": "/search/faux-real.jsp?CN=Brand:Faux%20Real&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Fifth Sun",
				"URL": "/search/fifth-sun.jsp?CN=Brand:Fifth%20Sun&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "FILA SPORT",
				"URL": "/search/fila-sport.jsp?CN=Brand:FILA%20SPORT&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "FILA SPORT GOLF",
				"URL": "/search/fila-sport-golf.jsp?CN=Brand:FILA%20SPORT%20GOLF&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Five Zone",
				"URL": "/search/five-zone.jsp?CN=Brand:Five%20Zone&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Food Network",
				"URL": "/search/food-network.jsp?CN=Brand:Food%20Network&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "French Toast",
				"URL": "/search/french-toast.jsp?CN=Brand:French%20Toast&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "G.H. Bass",
				"URL": "/search/gh-bass.jsp?CN=Brand:G.H.%20Bass&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Gildan",
				"URL": "/search/gildan.jsp?CN=Brand:Gildan&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "Gloria Vanderbilt",
				"URL": "/search/gloria-vanderbilt.jsp?CN=Brand:Gloria%20Vanderbilt&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Gold Series",
				"URL": "/search/gold-series.jsp?CN=Brand:Gold%20Series&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "GOLDTOE",
				"URL": "/search/goldtoe.jsp?CN=Brand:GOLDTOE&search=shirts&S=1&WS=0"
			}, {
				"productCount": 25,
				"isSelected": false,
				"name": "Grand Slam",
				"URL": "/search/grand-slam.jsp?CN=Brand:Grand%20Slam&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "Haggar",
				"URL": "/search/haggar.jsp?CN=Brand:Haggar&search=shirts&S=1&WS=0"
			}, {
				"productCount": 11,
				"isSelected": false,
				"name": "Hanes",
				"URL": "/search/hanes.jsp?CN=Brand:Hanes&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Hang Ten",
				"URL": "/search/hang-ten.jsp?CN=Brand:Hang%20Ten&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Harbor Bay",
				"URL": "/search/harbor-bay.jsp?CN=Brand:Harbor%20Bay&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "HeartSoul",
				"URL": "/search/heartsoul.jsp?CN=Brand:HeartSoul&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "HeatKeep",
				"URL": "/search/heatkeep.jsp?CN=Brand:HeatKeep&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Helix",
				"URL": "/search/helix.jsp?CN=Brand:Helix&search=shirts&S=1&WS=0"
			}, {
				"productCount": 21,
				"isSelected": false,
				"name": "Home Classics",
				"URL": "/search/home-classics.jsp?CN=Brand:Home%20Classics&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Huntworth",
				"URL": "/search/huntworth.jsp?CN=Brand:Huntworth&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "IZ Amy Byer",
				"URL": "/search/iz-amy-byer.jsp?CN=Brand:IZ%20Amy%20Byer&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "IZ Byer California",
				"URL": "/search/iz-byer-california.jsp?CN=Brand:IZ%20Byer%20California&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "IZOD",
				"URL": "/search/izod.jsp?CN=Brand:IZOD&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Jelli Fish Kids",
				"URL": "/search/jelli-fish-kids.jsp?CN=Brand:Jelli%20Fish%20Kids&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Jennifer Lopez",
				"URL": "/search/jennifer-lopez.jsp?CN=Brand:Jennifer%20Lopez&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Jester",
				"URL": "/search/jester.jsp?CN=Brand:Jester&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Jockey",
				"URL": "/search/jockey.jsp?CN=Brand:Jockey&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Juicy Couture",
				"URL": "/search/juicy-couture.jsp?CN=Brand:Juicy%20Couture&search=shirts&S=1&WS=0"
			}, {
				"productCount": 32,
				"isSelected": false,
				"name": "Jumping Beans",
				"URL": "/search/jumping-beans.jsp?CN=Brand:Jumping%20Beans&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Knitworks",
				"URL": "/search/knitworks.jsp?CN=Brand:Knitworks&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "LC Lauren Conrad",
				"URL": "/search/lc-lauren-conrad.jsp?CN=Brand:LC%20Lauren%20Conrad&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Leading Lady",
				"URL": "/search/leading-lady.jsp?CN=Brand:Leading%20Lady&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Lee",
				"URL": "/search/lee.jsp?CN=Brand:Lee&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "LEGO",
				"URL": "/search/lego.jsp?CN=Brand:LEGO&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Levi's",
				"URL": "/search/levis.jsp?CN=Brand:Levi%27s&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Maidenform",
				"URL": "/search/maidenform.jsp?CN=Brand:Maidenform&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Maidenform Shapewear",
				"URL": "/search/maidenform-shapewear.jsp?CN=Brand:Maidenform%20Shapewear&search=shirts&S=1&WS=0"
			}, {
				"productCount": 109,
				"isSelected": false,
				"name": "Majestic",
				"URL": "/search/majestic.jsp?CN=Brand:Majestic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 17,
				"isSelected": false,
				"name": "Marc Anthony",
				"URL": "/search/marc-anthony.jsp?CN=Brand:Marc%20Anthony&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Marika",
				"URL": "/search/marika.jsp?CN=Brand:Marika&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Marvel",
				"URL": "/search/marvel.jsp?CN=Brand:Marvel&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Maui and Sons",
				"URL": "/search/maui-and-sons.jsp?CN=Brand:Maui%20and%20Sons&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Method",
				"URL": "/search/method.jsp?CN=Brand:Method&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Mohawk Home",
				"URL": "/search/mohawk-home.jsp?CN=Brand:Mohawk%20Home&search=shirts&S=1&WS=0"
			}, {
				"productCount": 18,
				"isSelected": false,
				"name": "Mudd",
				"URL": "/search/mudd.jsp?CN=Brand:Mudd&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Nanofibre",
				"URL": "/search/nanofibre.jsp?CN=Brand:Nanofibre&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "New Balance",
				"URL": "/search/new-balance.jsp?CN=Brand:New%20Balance&search=shirts&S=1&WS=0"
			}, {
				"productCount": 33,
				"isSelected": false,
				"name": "Newport Blue",
				"URL": "/search/newport-blue.jsp?CN=Brand:Newport%20Blue&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Nick Faldo",
				"URL": "/search/nick-faldo.jsp?CN=Brand:Nick%20Faldo&search=shirts&S=1&WS=0"
			}, {
				"productCount": 93,
				"isSelected": false,
				"name": "Nike",
				"URL": "/search/nike.jsp?CN=Brand:Nike&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Oh Baby by Motherhood",
				"URL": "/search/oh-baby-by-motherhood.jsp?CN=Brand:Oh%20Baby%20by%20Motherhood&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Old Time Hockey",
				"URL": "/search/old-time-hockey.jsp?CN=Brand:Old%20Time%20Hockey&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Olga",
				"URL": "/search/olga.jsp?CN=Brand:Olga&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Olivia Sky",
				"URL": "/search/olivia-sky.jsp?CN=Brand:Olivia%20Sky&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "OXO",
				"URL": "/search/oxo.jsp?CN=Brand:OXO&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Playmobil",
				"URL": "/search/playmobil.jsp?CN=Brand:Playmobil&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Princess Vera Wang",
				"URL": "/search/princess-vera-wang.jsp?CN=Brand:Princess%20Vera%20Wang&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "R&O",
				"URL": "/search/ro.jsp?CN=Brand:R%26O&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Red X",
				"URL": "/search/red-x.jsp?CN=Brand:Red%20X&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "Reebok",
				"URL": "/search/reebok.jsp?CN=Brand:Reebok&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "Rock & Republic",
				"URL": "/search/rock-republic.jsp?CN=Brand:Rock%20%26%20Republic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Russell Athletic",
				"URL": "/search/russell-athletic.jsp?CN=Brand:Russell%20Athletic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Ryka",
				"URL": "/search/ryka.jsp?CN=Brand:Ryka&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Safe Harbor",
				"URL": "/search/safe-harbor.jsp?CN=Brand:Safe%20Harbor&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Sag Harbor",
				"URL": "/search/sag-harbor.jsp?CN=Brand:Sag%20Harbor&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "SensorPEDIC",
				"URL": "/search/sensorpedic.jsp?CN=Brand:SensorPEDIC&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Serta",
				"URL": "/search/serta.jsp?CN=Brand:Serta&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Simply Vera Vera Wang",
				"URL": "/search/simply-vera-vera-wang.jsp?CN=Brand:Simply%20Vera%20Vera%20Wang&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Skechers",
				"URL": "/search/skechers.jsp?CN=Brand:Skechers&search=shirts&S=1&WS=0"
			}, {
				"productCount": 23,
				"isSelected": false,
				"name": "SO",
				"URL": "/search/so.jsp?CN=Brand:SO&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Soffe",
				"URL": "/search/soffe.jsp?CN=Brand:Soffe&search=shirts&S=1&WS=0"
			}, {
				"productCount": 36,
				"isSelected": false,
				"name": "SONOMA life + style",
				"URL": "/search/sonoma-life-style.jsp?CN=Brand:SONOMA%20life%20%2B%20style&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "SONOMA outdoors",
				"URL": "/search/sonoma-outdoors.jsp?CN=Brand:SONOMA%20outdoors&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "St. Nicholas Square",
				"URL": "/search/st-nicholas-square.jsp?CN=Brand:St.%20Nicholas%20Square&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Steve Harvey",
				"URL": "/search/steve-harvey.jsp?CN=Brand:Steve%20Harvey&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "STUDIO Tahari-Levine Co.",
				"URL": "/search/studio-taharilevine-co.jsp?CN=Brand:STUDIO%20Tahari-Levine%20Co.&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Sunbeam",
				"URL": "/search/sunbeam.jsp?CN=Brand:Sunbeam&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Superfit Curves",
				"URL": "/search/superfit-curves.jsp?CN=Brand:Superfit%20Curves&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Taboo",
				"URL": "/search/taboo.jsp?CN=Brand:Taboo&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Tail",
				"URL": "/search/tail.jsp?CN=Brand:Tail&search=shirts&S=1&WS=0"
			}, {
				"productCount": 20,
				"isSelected": false,
				"name": "Tek Gear",
				"URL": "/search/tek-gear.jsp?CN=Brand:Tek%20Gear&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "The Big One",
				"URL": "/search/the-big-one.jsp?CN=Brand:The%20Big%20One&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Tony Hawk",
				"URL": "/search/tony-hawk.jsp?CN=Brand:Tony%20Hawk&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Top Heavy",
				"URL": "/search/top-heavy.jsp?CN=Brand:Top%20Heavy&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Top of the World",
				"URL": "/search/top-of-the-world.jsp?CN=Brand:Top%20of%20the%20World&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Umbro",
				"URL": "/search/umbro.jsp?CN=Brand:Umbro&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Unionbay",
				"URL": "/search/unionbay.jsp?CN=Brand:Unionbay&search=shirts&S=1&WS=0"
			}, {
				"productCount": 15,
				"isSelected": false,
				"name": "Urban Pipeline",
				"URL": "/search/urban-pipeline.jsp?CN=Brand:Urban%20Pipeline&search=shirts&S=1&WS=0"
			}, {
				"productCount": 33,
				"isSelected": false,
				"name": "Van Heusen",
				"URL": "/search/van-heusen.jsp?CN=Brand:Van%20Heusen&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Vanity Fair",
				"URL": "/search/vanity-fair.jsp?CN=Brand:Vanity%20Fair&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Vans",
				"URL": "/search/vans.jsp?CN=Brand:Vans&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Warner's",
				"URL": "/search/warners.jsp?CN=Brand:Warner%27s&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Weavers Girl",
				"URL": "/search/weavers-girl.jsp?CN=Brand:Weavers%20Girl&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Wolverine",
				"URL": "/search/wolverine.jsp?CN=Brand:Wolverine&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Wonderbra",
				"URL": "/search/wonderbra.jsp?CN=Brand:Wonderbra&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Wrapper",
				"URL": "/search/wrapper.jsp?CN=Brand:Wrapper&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Xg",
				"URL": "/search/xg.jsp?CN=Brand:Xg&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Youngland",
				"URL": "/search/youngland.jsp?CN=Brand:Youngland&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "ZeroXposur",
				"URL": "/search/zeroxposur.jsp?CN=Brand:ZeroXposur&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Zoo York",
				"URL": "/search/zoo-york.jsp?CN=Brand:Zoo%20York&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Brand"
		}, {
			"dimension": "Color",
			"facets": [{
				"productCount": 54,
				"isSelected": false,
				"name": "Beig/khaki",
				"URL": "/search/beigkhaki.jsp?CN=Color:Beig%7Ekhaki&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Beige",
				"URL": "/search/beige.jsp?CN=Color:Beige&search=shirts&S=1&WS=0"
			}, {
				"productCount": 320,
				"isSelected": false,
				"name": "Black",
				"URL": "/search/black.jsp?CN=Color:Black&search=shirts&S=1&WS=0"
			}, {
				"productCount": 486,
				"isSelected": false,
				"name": "Blue",
				"URL": "/search/blue.jsp?CN=Color:Blue&search=shirts&S=1&WS=0"
			}, {
				"productCount": 68,
				"isSelected": false,
				"name": "Brown",
				"URL": "/search/brown.jsp?CN=Color:Brown&search=shirts&S=1&WS=0"
			}, {
				"productCount": 119,
				"isSelected": false,
				"name": "Green",
				"URL": "/search/green.jsp?CN=Color:Green&search=shirts&S=1&WS=0"
			}, {
				"productCount": 290,
				"isSelected": false,
				"name": "Grey",
				"URL": "/search/grey.jsp?CN=Color:Grey&search=shirts&S=1&WS=0"
			}, {
				"productCount": 37,
				"isSelected": false,
				"name": "Multi/none",
				"URL": "/search/multinone.jsp?CN=Color:Multi%7Enone&search=shirts&S=1&WS=0"
			}, {
				"productCount": 65,
				"isSelected": false,
				"name": "Orange",
				"URL": "/search/orange.jsp?CN=Color:Orange&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "Other",
				"URL": "/search/other.jsp?CN=Color:Other&search=shirts&S=1&WS=0"
			}, {
				"productCount": 25,
				"isSelected": false,
				"name": "Other clrs",
				"URL": "/search/other-clrs.jsp?CN=Color:Other%20clrs&search=shirts&S=1&WS=0"
			}, {
				"productCount": 65,
				"isSelected": false,
				"name": "Pink",
				"URL": "/search/pink.jsp?CN=Color:Pink&search=shirts&S=1&WS=0"
			}, {
				"productCount": 93,
				"isSelected": false,
				"name": "Purple",
				"URL": "/search/purple.jsp?CN=Color:Purple&search=shirts&S=1&WS=0"
			}, {
				"productCount": 230,
				"isSelected": false,
				"name": "Red",
				"URL": "/search/red.jsp?CN=Color:Red&search=shirts&S=1&WS=0"
			}, {
				"productCount": 285,
				"isSelected": false,
				"name": "White",
				"URL": "/search/white.jsp?CN=Color:White&search=shirts&S=1&WS=0"
			}, {
				"productCount": 41,
				"isSelected": false,
				"name": "Yellow",
				"URL": "/search/yellow.jsp?CN=Color:Yellow&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Color"
		}, {
			"dimension": "Material",
			"facets": [{
				"productCount": 1,
				"isSelected": false,
				"name": "Acrylic",
				"URL": "/search/acrylic.jsp?CN=Material:Acrylic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Acrylic Blend",
				"URL": "/search/acrylic-blend.jsp?CN=Material:Acrylic%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 16,
				"isSelected": false,
				"name": "Canvas",
				"URL": "/search/canvas.jsp?CN=Material:Canvas&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Cashmere",
				"URL": "/search/cashmere.jsp?CN=Material:Cashmere&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Chiffon",
				"URL": "/search/chiffon.jsp?CN=Material:Chiffon&search=shirts&S=1&WS=0"
			}, {
				"productCount": 464,
				"isSelected": false,
				"name": "Cotton",
				"URL": "/search/cotton.jsp?CN=Material:Cotton&search=shirts&S=1&WS=0"
			}, {
				"productCount": 487,
				"isSelected": false,
				"name": "Cotton Blend",
				"URL": "/search/cotton-blend.jsp?CN=Material:Cotton%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Cotton/Polyester",
				"URL": "/search/cottonpolyester.jsp?CN=Material:Cotton%7EPolyester&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Denim",
				"URL": "/search/denim.jsp?CN=Material:Denim&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Fabric",
				"URL": "/search/fabric.jsp?CN=Material:Fabric&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Faux Leather",
				"URL": "/search/faux-leather.jsp?CN=Material:Faux%20Leather&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Flannel",
				"URL": "/search/flannel.jsp?CN=Material:Flannel&search=shirts&S=1&WS=0"
			}, {
				"productCount": 157,
				"isSelected": false,
				"name": "Fleece",
				"URL": "/search/fleece.jsp?CN=Material:Fleece&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "French Terry",
				"URL": "/search/french-terry.jsp?CN=Material:French%20Terry&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Jersey",
				"URL": "/search/jersey.jsp?CN=Material:Jersey&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Leather",
				"URL": "/search/leather.jsp?CN=Material:Leather&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Linen",
				"URL": "/search/linen.jsp?CN=Material:Linen&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Merino Wool",
				"URL": "/search/merino-wool.jsp?CN=Material:Merino%20Wool&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "Mesh",
				"URL": "/search/mesh.jsp?CN=Material:Mesh&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Metal",
				"URL": "/search/metal.jsp?CN=Material:Metal&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Microfiber",
				"URL": "/search/microfiber.jsp?CN=Material:Microfiber&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "No Cover",
				"URL": "/search/no-cover.jsp?CN=Material:No%20Cover&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "None",
				"URL": "/search/none.jsp?CN=Material:None&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Nylon",
				"URL": "/search/nylon.jsp?CN=Material:Nylon&search=shirts&S=1&WS=0"
			}, {
				"productCount": 16,
				"isSelected": false,
				"name": "Nylon Blend",
				"URL": "/search/nylon-blend.jsp?CN=Material:Nylon%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "Nylon Spandex",
				"URL": "/search/nylon-spandex.jsp?CN=Material:Nylon%20Spandex&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Nylon/Spandex",
				"URL": "/search/nylonspandex.jsp?CN=Material:Nylon%7ESpandex&search=shirts&S=1&WS=0"
			}, {
				"productCount": 157,
				"isSelected": false,
				"name": "Other",
				"URL": "/search/other.jsp?CN=Material:Other&search=shirts&S=1&WS=0"
			}, {
				"productCount": 49,
				"isSelected": false,
				"name": "Other Material",
				"URL": "/search/other-material.jsp?CN=Material:Other%20Material&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Plastic",
				"URL": "/search/plastic.jsp?CN=Material:Plastic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Polar Fleece",
				"URL": "/search/polar-fleece.jsp?CN=Material:Polar%20Fleece&search=shirts&S=1&WS=0"
			}, {
				"productCount": 55,
				"isSelected": false,
				"name": "Poly Blend",
				"URL": "/search/poly-blend.jsp?CN=Material:Poly%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 133,
				"isSelected": false,
				"name": "Polyester",
				"URL": "/search/polyester.jsp?CN=Material:Polyester&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Rayon",
				"URL": "/search/rayon.jsp?CN=Material:Rayon&search=shirts&S=1&WS=0"
			}, {
				"productCount": 9,
				"isSelected": false,
				"name": "Rayon Blend",
				"URL": "/search/rayon-blend.jsp?CN=Material:Rayon%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Satin",
				"URL": "/search/satin.jsp?CN=Material:Satin&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Silk",
				"URL": "/search/silk.jsp?CN=Material:Silk&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "Slub",
				"URL": "/search/slub.jsp?CN=Material:Slub&search=shirts&S=1&WS=0"
			}, {
				"productCount": 5,
				"isSelected": false,
				"name": "Spandex Blend",
				"URL": "/search/spandex-blend.jsp?CN=Material:Spandex%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 10,
				"isSelected": false,
				"name": "Synthetic",
				"URL": "/search/synthetic.jsp?CN=Material:Synthetic&search=shirts&S=1&WS=0"
			}, {
				"productCount": 3,
				"isSelected": false,
				"name": "Unknown Material",
				"URL": "/search/unknown-material.jsp?CN=Material:Unknown%20Material&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "Velour",
				"URL": "/search/velour.jsp?CN=Material:Velour&search=shirts&S=1&WS=0"
			}, {
				"productCount": 6,
				"isSelected": false,
				"name": "Wool",
				"URL": "/search/wool.jsp?CN=Material:Wool&search=shirts&S=1&WS=0"
			}, {
				"productCount": 8,
				"isSelected": false,
				"name": "Wool & Wool Blend",
				"URL": "/search/wool-wool-blend.jsp?CN=Material:Wool%20%26%20Wool%20Blend&search=shirts&S=1&WS=0"
			}, {
				"productCount": 4,
				"isSelected": false,
				"name": "Wool Blend",
				"URL": "/search/wool-blend.jsp?CN=Material:Wool%20Blend&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Material"
		}, {
			"dimension": "Price",
			"facets": [{
				"productCount": 204,
				"isSelected": false,
				"name": "Under $10",
				"URL": "/search.jsp?CN=Price:Under%20%2410&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 584,
				"isSelected": false,
				"name": "$10 to $25",
				"URL": "/search.jsp?CN=Price:%2410%20to%20%2425&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 700,
				"isSelected": false,
				"name": "$25 to $50",
				"URL": "/search.jsp?CN=Price:%2425%20to%20%2450&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 444,
				"isSelected": false,
				"name": "$50 to $100",
				"URL": "/search.jsp?CN=Price:%2450%20to%20%24100&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 130,
				"isSelected": false,
				"name": "$100 to $250",
				"URL": "/search.jsp?CN=Price:%24100%20to%20%24250&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 28,
				"isSelected": false,
				"name": "$250 to $500",
				"URL": "/search.jsp?CN=Price:%24250%20to%20%24500&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 2,
				"isSelected": false,
				"name": "$500 to $1000",
				"URL": "/search.jsp?CN=Price:%24500%20to%20%241000&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 7,
				"isSelected": false,
				"name": "$1000 to $3000",
				"URL": "/search.jsp?CN=Price:%241000%20to%20%243000&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 1,
				"isSelected": false,
				"name": "$3000 and above",
				"URL": "/search.jsp?CN=Price:%243000%20and%20above&BL=y&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "Price"
		}, {
			"dimension": "Rating",
			"facets": [{
				"productCount": 122,
				"isSelected": false,
				"name": "5",
				"URL": "/search.jsp?CN=TopRated:5&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 143,
				"isSelected": false,
				"name": "4",
				"URL": "/search.jsp?CN=TopRated:4&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 51,
				"isSelected": false,
				"name": "3",
				"URL": "/search.jsp?CN=TopRated:3&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 29,
				"isSelected": false,
				"name": "2",
				"URL": "/search.jsp?CN=TopRated:2&BL=y&search=shirts&S=1&WS=0"
			}, {
				"productCount": 12,
				"isSelected": false,
				"name": "1",
				"URL": "/search.jsp?CN=TopRated:1&BL=y&search=shirts&S=1&WS=0"
			}],
			"dimensionName": "TopRated"
		}],
		"linkCartridge": {
			"cartridgeName": "",
			"linkGroup": []
		}
	},
	"productInfo": {
		"productList": [{
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": true,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/825463_Black?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "Black",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Solid Broadcloth&nbsp;Point-Collar Dress Shirt",
			"prodSeoURL": "/product/prd-825463/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp",
			"productId": "825463",
			"availableColors": ["Black", "White", "French Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-4-0",
				"reviewTitle": "25 reviews",
				"reviewURL": "/product/prd-825463/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "4.0",
				"reviewCount": "25",
				"ratingsTitle": "Ratings : 4.0 of 5.0",
				"ratingsURL": "/product/prd-825463/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$19.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/689516_White?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"offerType": "GWP",
			"purchaseType": "BUY",
			"prodType": "product",
			"displayColor": "White",
			"productTitle": "Croft &amp; Barrow&reg; Classic Fit Solid Button-Down Collar Easy-Care Dress Shirt",
			"prodSeoURL": "/product/prd-689516/croft-barrow-classic-fit-solid-button-down-collar-easy-care-dress-shirt.jsp",
			"productId": "689516",
			"availableColors": ["White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-1-9",
				"reviewTitle": "18 reviews",
				"reviewURL": "/product/prd-689516/croft-barrow-classic-fit-solid-button-down-collar-easy-care-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "1.9",
				"reviewCount": "18",
				"ratingsTitle": "Ratings : 1.9 of 5.0",
				"ratingsURL": "/product/prd-689516/croft-barrow-classic-fit-solid-button-down-collar-easy-care-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$12.99 - $14.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1225471_Estate_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "Estate Blue",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Solid Broadcloth Point Collar Dress Shirt",
			"prodSeoURL": "/product/prd-1225471/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp",
			"productId": "1225471",
			"availableColors": ["Estate Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1225471/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1225471/croft-barrow-classic-fit-solid-broadcloth-point-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$42.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1151180_Dark_Navy?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Dark Navy",
			"productTitle": "Dickies Performance Twill Work Shirt - Women's",
			"prodSeoURL": "/product/prd-1151180/dickies-performance-twill-work-shirt-womens.jsp",
			"productId": "1151180",
			"availableColors": ["Black", "Dark Navy", "Graphite", "Khaki"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1151180/dickies-performance-twill-work-shirt-womens.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1151180/dickies-performance-twill-work-shirt-womens.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$24.00",
				"salePrice": "$12.00 - $24.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": ["BUY 2 AND GET AN EXTRA 15% OFF!", "BUY 3 AND GET AN EXTRA 20% OFF!", "BUY 4 AND GET AN EXTRA 25% OFF!"],
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/387673_Yellow?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "Yellow",
			"productTitle": "<p>Chaps Solid Oxford Dress Button-Down Shirt</p>",
			"prodSeoURL": "/product/prd-387673/chaps-solid-oxford-dress-button-down-shirt.jsp",
			"productId": "387673",
			"availableColors": ["Yellow", "Blue", "White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-4-0",
				"reviewTitle": "3 reviews",
				"reviewURL": "/product/prd-387673/chaps-solid-oxford-dress-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "4.0",
				"reviewCount": "3",
				"ratingsTitle": "Ratings : 4.0 of 5.0",
				"ratingsURL": "/product/prd-387673/chaps-solid-oxford-dress-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$34.00",
				"salePrice": "$23.80",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1127504?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "Dark Grey",
			"productTitle": "Chaps Iridescent Striped Button-Down Shirt - Boys 8-20",
			"prodSeoURL": "/product/prd-1127504/chaps-iridescent-striped-button-down-shirt-boys-8-20.jsp",
			"productId": "1127504",
			"availableColors": ["Dark Grey"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1127504/chaps-iridescent-striped-button-down-shirt-boys-8-20.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1127504/chaps-iridescent-striped-button-down-shirt-boys-8-20.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$22.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1438041_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "White",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Solid Broadcloth Button-Down Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1438041/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-big-tall.jsp",
			"productId": "1438041",
			"availableColors": ["White", "Studio White", "Black"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1438041/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1438041/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$28.00",
				"salePrice": "$19.60",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1098383_French_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "French Blue",
			"productTitle": "Chaps Solid Oxford Button-Down Shirt - Boys 8-20",
			"prodSeoURL": "/product/prd-1098383/chaps-solid-oxford-button-down-shirt-boys-8-20.jsp",
			"productId": "1098383",
			"availableColors": ["French Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-5-0",
				"reviewTitle": "3 reviews",
				"reviewURL": "/product/prd-1098383/chaps-solid-oxford-button-down-shirt-boys-8-20.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "5.0",
				"reviewCount": "3",
				"ratingsTitle": "Ratings : 5.0 of 5.0",
				"ratingsURL": "/product/prd-1098383/chaps-solid-oxford-button-down-shirt-boys-8-20.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$48.00",
				"salePrice": "$28.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1437219_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Solid Easy-Care Button-Down Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1437219/croft-barrow-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp",
			"productId": "1437219",
			"availableColors": ["Studio White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1437219/croft-barrow-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1437219/croft-barrow-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$29.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/663275_Navy?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Navy",
			"productTitle": "Dickies Original Fit Twill Work Shirt",
			"prodSeoURL": "/product/prd-663275/dickies-original-fit-twill-work-shirt.jsp",
			"productId": "663275",
			"availableColors": ["Navy", "Khaki", "Charcoal"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-5-0",
				"reviewTitle": "4 reviews",
				"reviewURL": "/product/prd-663275/dickies-original-fit-twill-work-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "5.0",
				"reviewCount": "4",
				"ratingsTitle": "Ratings : 5.0 of 5.0",
				"ratingsURL": "/product/prd-663275/dickies-original-fit-twill-work-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1177683_White?wid=240&hei=240&op_sharpen=1",
			"badges": [],
			"prodType": "product",
			"displayColor": "White",
			"productTitle": "Croft &amp; Barrow&reg; Slim-Fit Solid Broadcloth Spread-Collar Dress Shirt",
			"prodSeoURL": "/product/prd-1177683/croft-barrow-slim-fit-solid-broadcloth-spread-collar-dress-shirt.jsp",
			"productId": "1177683",
			"availableColors": ["White", "Gray"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-2-7",
				"reviewTitle": "3 reviews",
				"reviewURL": "/product/prd-1177683/croft-barrow-slim-fit-solid-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "2.7",
				"reviewCount": "3",
				"ratingsTitle": "Ratings : 2.7 of 5.0",
				"ratingsURL": "/product/prd-1177683/croft-barrow-slim-fit-solid-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$70.00",
				"salePrice": "$42.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1436741?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; No Iron Point-Collar Button-Down Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1436741/croft-barrow-no-iron-point-collar-button-down-dress-shirt-big-tall.jsp",
			"productId": "1436741",
			"availableColors": ["Studio White"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1436741/croft-barrow-no-iron-point-collar-button-down-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1436741/croft-barrow-no-iron-point-collar-button-down-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1170622_Powder_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Powder Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Classic-Fit Solid Broadcloth Button-Down Collar Dress Shirt - Men</p>",
			"prodSeoURL": "/product/prd-1170622/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-men.jsp",
			"productId": "1170622",
			"availableColors": ["Powder Blue", "Light Gray"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-2-6",
				"reviewTitle": "16 reviews",
				"reviewURL": "/product/prd-1170622/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "2.6",
				"reviewCount": "16",
				"ratingsTitle": "Ratings : 2.6 of 5.0",
				"ratingsURL": "/product/prd-1170622/croft-barrow-classic-fit-solid-broadcloth-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$48.00",
				"salePrice": "$28.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1437217_Red?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Red",
			"productTitle": "Croft &amp; Barrow&reg; Striped Easy-Care Button-Down Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1437217/croft-barrow-striped-easy-care-button-down-collar-dress-shirt-big-tall.jsp",
			"productId": "1437217",
			"availableColors": ["Red"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1437217/croft-barrow-striped-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1437217/croft-barrow-striped-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$66.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1129287_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "White",
			"productTitle": "<strong>Chaps Classic-Fit Solid Oxford Casual Button-Down Shirt - Big &amp; Tall</strong>",
			"prodSeoURL": "/product/prd-1129287/chaps-classic-fit-solid-oxford-casual-button-down-shirt-big-tall.jsp",
			"productId": "1129287",
			"availableColors": ["White"],
			"variations": "SizeAndColor",
			"altImageUrl": "https://media.kohlsimg.com/is/image/kohls/2816200_Lilac",
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1129287/chaps-classic-fit-solid-oxford-casual-button-down-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1129287/chaps-classic-fit-solid-oxford-casual-button-down-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1170625_French_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "French Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Classic-Fit Solid Easy-Care Spread-Collar Dress Shirt</p>",
			"prodSeoURL": "/product/prd-1170625/croft-barrow-classic-fit-solid-easy-care-spread-collar-dress-shirt.jsp",
			"productId": "1170625",
			"availableColors": ["Gray", "French Blue", "White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-3-0",
				"reviewTitle": "4 reviews",
				"reviewURL": "/product/prd-1170625/croft-barrow-classic-fit-solid-easy-care-spread-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "3.0",
				"reviewCount": "4",
				"ratingsTitle": "Ratings : 3.0 of 5.0",
				"ratingsURL": "/product/prd-1170625/croft-barrow-classic-fit-solid-easy-care-spread-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$12.99 - $32.00",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1170626_Blue_Bonnet?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Blue Bonnet",
			"productTitle": "Croft &amp; Barrow&reg; Fitted Solid Broadcloth Spread-Collar Dress Shirt",
			"prodSeoURL": "/product/prd-1170626/croft-barrow-fitted-solid-broadcloth-spread-collar-dress-shirt.jsp",
			"productId": "1170626",
			"availableColors": ["Blue Bonnet", "Powder Blue", "White", "French Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-3-0",
				"reviewTitle": "1 reviews",
				"reviewURL": "/product/prd-1170626/croft-barrow-fitted-solid-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "3.0",
				"reviewCount": "1",
				"ratingsTitle": "Ratings : 3.0 of 5.0",
				"ratingsURL": "/product/prd-1170626/croft-barrow-fitted-solid-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": true,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1177088_Black?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Black",
			"productTitle": "Croft &amp; Barrow&reg; Fitted Solid Broadcloth Button-Down Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1177088/croft-barrow-fitted-solid-broadcloth-button-down-collar-dress-shirt-men.jsp",
			"productId": "1177088",
			"availableColors": ["Gray", "Black", "Blue Bonnet", "French Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-5-0",
				"reviewTitle": "1 reviews",
				"reviewURL": "/product/prd-1177088/croft-barrow-fitted-solid-broadcloth-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "5.0",
				"reviewCount": "1",
				"ratingsTitle": "Ratings : 5.0 of 5.0",
				"ratingsURL": "/product/prd-1177088/croft-barrow-fitted-solid-broadcloth-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1278103_Powder_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Powder Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Solid Broadcloth Point-Collar Dress Shirt - Big &amp; Tall</p>",
			"prodSeoURL": "/product/prd-1278103/croft-and-barrow-solid-broadcloth-point-collar-dress-shirt-big-and-tall.jsp",
			"productId": "1278103",
			"availableColors": ["Powder Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-3-9",
				"reviewTitle": "10 reviews",
				"reviewURL": "/product/prd-1278103/croft-and-barrow-solid-broadcloth-point-collar-dress-shirt-big-and-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "3.9",
				"reviewCount": "10",
				"ratingsTitle": "Ratings : 3.9 of 5.0",
				"ratingsURL": "/product/prd-1278103/croft-and-barrow-solid-broadcloth-point-collar-dress-shirt-big-and-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$22.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1278131_Blue_Bonnet?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Blue Bonnet",
			"productTitle": "Croft &amp; Barrow&reg; Solid Broadcloth Spread-Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1278131/croft-barrow-solid-broadcloth-spread-collar-dress-shirt-big-tall.jsp",
			"productId": "1278131",
			"availableColors": ["Blue Bonnet"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-2-5",
				"reviewTitle": "2 reviews",
				"reviewURL": "/product/prd-1278131/croft-barrow-solid-broadcloth-spread-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "2.5",
				"reviewCount": "2",
				"ratingsTitle": "Ratings : 2.5 of 5.0",
				"ratingsURL": "/product/prd-1278131/croft-barrow-solid-broadcloth-spread-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$19.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1276544_Red?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Red",
			"productTitle": "<p>Croft &amp; Barrow&reg; Slim-Fit Striped Easy-Care Button-Down-Collar Dress Shirt - Men</p>",
			"prodSeoURL": "/product/prd-1276544/croft-barrow-slim-fit-striped-easy-care-button-down-collar-dress-shirt-men.jsp",
			"productId": "1276544",
			"availableColors": ["Red"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1276544/croft-barrow-slim-fit-striped-easy-care-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1276544/croft-barrow-slim-fit-striped-easy-care-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1263725?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}, {
				"imageURL": "/snb/media/images/bogo_images/bogo_1_1_P_50_v1_m56577569835792921.gif",
				"altText": "BUY_1_GET_1_50_PERCENTAGE",
				"imageName": "BUY_1_GET_1_50_PERCENTAGE"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Slim-Fit Solid Easy-Care Button-Down Collar Dress Shirt - Big &amp; Tall</p>",
			"prodSeoURL": "/product/prd-1263725/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp",
			"productId": "1263725",
			"availableColors": ["Light Blue"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-4-0",
				"reviewTitle": "1 reviews",
				"reviewURL": "/product/prd-1263725/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "4.0",
				"reviewCount": "1",
				"ratingsTitle": "Ratings : 4.0 of 5.0",
				"ratingsURL": "/product/prd-1263725/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1263950_Black?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Black",
			"productTitle": "Croft&nbsp;&amp; Barrow&reg;&nbsp;Classic-Fit Striped Broadcloth Spread-Collar Dress Shirt",
			"prodSeoURL": "/product/prd-1263950/croft-barrow-classic-fit-striped-broadcloth-spread-collar-dress-shirt.jsp",
			"productId": "1263950",
			"availableColors": ["Black"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"ratingStar": "stars stars-4-7",
				"reviewTitle": "3 reviews",
				"reviewURL": "/product/prd-1263950/croft-barrow-classic-fit-striped-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": "4.7",
				"reviewCount": "3",
				"ratingsTitle": "Ratings : 4.7 of 5.0",
				"ratingsURL": "/product/prd-1263950/croft-barrow-classic-fit-striped-broadcloth-spread-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$30.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1480694_Aged_Brick?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Aged Brick",
			"productTitle": "Dickies Plaid Shirt - Men",
			"prodSeoURL": "/product/prd-1480694/dickies-plaid-shirt-men.jsp",
			"productId": "1480694",
			"availableColors": ["Aged Brick"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1480694/dickies-plaid-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1480694/dickies-plaid-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1512324_Palace_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Palace Blue",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Herringbone French Cuff No Iron Spread-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1512324/croft-barrow-classic-fit-herringbone-french-cuff-no-iron-spread-collar-dress-shirt-men.jsp",
			"productId": "1512324",
			"availableColors": ["Palace Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1512324/croft-barrow-classic-fit-herringbone-french-cuff-no-iron-spread-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1512324/croft-barrow-classic-fit-herringbone-french-cuff-no-iron-spread-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$34.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1522851_Light_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "Lee School Uniform Slim-Fit Oxford Button-Down Shirt",
			"prodSeoURL": "/product/prd-1522851/lee-school-uniform-slim-fit-oxford-button-down-shirt.jsp",
			"productId": "1522851",
			"availableColors": ["Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1522851/lee-school-uniform-slim-fit-oxford-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1522851/lee-school-uniform-slim-fit-oxford-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1600636?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Antique White",
			"productTitle": "Centro Plaid Casual Button-Down Shirt - Men",
			"prodSeoURL": "/product/prd-1600636/centro-plaid-casual-button-down-shirt-men.jsp",
			"productId": "1600636",
			"availableColors": ["Antique White"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1600636/centro-plaid-casual-button-down-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1600636/centro-plaid-casual-button-down-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$34.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1524590_Light_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "Lee School Uniform Classic-Fit Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1524590/lee-school-uniform-classic-fit-dress-shirt-men.jsp",
			"productId": "1524590",
			"availableColors": ["Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1524590/lee-school-uniform-classic-fit-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1524590/lee-school-uniform-classic-fit-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$66.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1432892_Timber?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Timber",
			"productTitle": "Dickies Brushed Back Canvas Shirt - Men",
			"prodSeoURL": "/product/prd-1432892/dickies-brushed-back-canvas-shirt-men.jsp",
			"productId": "1432892",
			"availableColors": ["Timber"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1432892/dickies-brushed-back-canvas-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1432892/dickies-brushed-back-canvas-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$70.00",
				"salePrice": "$38.50 - $42.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1436737_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Core No Iron Button-Down Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1436737/croft-barrow-core-no-iron-button-down-dress-shirt-big-tall.jsp",
			"productId": "1436737",
			"availableColors": ["Studio White", "True Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1436737/croft-barrow-core-no-iron-button-down-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1436737/croft-barrow-core-no-iron-button-down-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$70.00",
				"salePrice": "$42.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1436806_Navy_Herringbone?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Navy Herringbone",
			"productTitle": "Croft &amp; Barrow Herringbone No Iron Spread-Collar Button-Down Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1436806/croft-barrow-herringbone-no-iron-spread-collar-button-down-dress-shirt-big-tall.jsp",
			"productId": "1436806",
			"availableColors": ["Navy Herringbone"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1436806/croft-barrow-herringbone-no-iron-spread-collar-button-down-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1436806/croft-barrow-herringbone-no-iron-spread-collar-button-down-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1350994?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Olympian Blue",
			"productTitle": "Centro Embroidered Diamond Casual Button-Down Shirt",
			"prodSeoURL": "/product/prd-1350994/centro-embroidered-diamond-casual-button-down-shirt.jsp",
			"productId": "1350994",
			"availableColors": ["Olympian Blue"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1350994/centro-embroidered-diamond-casual-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1350994/centro-embroidered-diamond-casual-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$48.00",
				"salePrice": "$28.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1437218_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Solid Easy-Care Spread-Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1437218/croft-barrow-solid-easy-care-spread-collar-dress-shirt-big-tall.jsp",
			"productId": "1437218",
			"availableColors": ["Studio White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1437218/croft-barrow-solid-easy-care-spread-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1437218/croft-barrow-solid-easy-care-spread-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1411777?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Ivy",
			"productTitle": "Chaps Ontario Plaid Oxford Casual Button-Down Shirt",
			"prodSeoURL": "/product/prd-1411777/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp",
			"productId": "1411777",
			"availableColors": ["Ivy"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1411777/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1411777/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$22.80",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1438132_Estate_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Estate Blue",
			"productTitle": "Croft &amp; Barrow&reg; Solid Broadcloth Button-Down Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1438132/croft-barrow-solid-broadcloth-button-down-dress-shirt-big-tall.jsp",
			"productId": "1438132",
			"availableColors": ["Estate Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1438132/croft-barrow-solid-broadcloth-button-down-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1438132/croft-barrow-solid-broadcloth-button-down-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$40.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1419214_Charcoal?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Charcoal",
			"productTitle": "Wolverine Burke Fleece Crew Shirt - Men",
			"prodSeoURL": "/product/prd-1419214/wolverine-burke-fleece-crew-shirt-men.jsp",
			"productId": "1419214",
			"availableColors": ["Charcoal"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1419214/wolverine-burke-fleece-crew-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1419214/wolverine-burke-fleece-crew-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1419277_Charcoal?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Charcoal",
			"productTitle": "Wolverine Sutton Chamois Button-Down Shirt - Men",
			"prodSeoURL": "/product/prd-1419277/wolverine-sutton-chamois-button-down-shirt-men.jsp",
			"productId": "1419277",
			"availableColors": ["Charcoal"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1419277/wolverine-sutton-chamois-button-down-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1419277/wolverine-sutton-chamois-button-down-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1424768_Bachelor_Button?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Bachelor Button",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Mini-Checked Point-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1424768/croft-barrow-classic-fit-mini-checked-point-collar-dress-shirt-men.jsp",
			"productId": "1424768",
			"availableColors": ["Bachelor Button"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1424768/croft-barrow-classic-fit-mini-checked-point-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1424768/croft-barrow-classic-fit-mini-checked-point-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": true,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1424917_True_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "True Blue",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit No Iron Button Down-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1424917/croft-barrow-classic-fit-no-iron-button-down-collar-dress-shirt-men.jsp",
			"productId": "1424917",
			"availableColors": ["True Blue", "Frosty Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1424917/croft-barrow-classic-fit-no-iron-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1424917/croft-barrow-classic-fit-no-iron-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1424923_Frosty_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Frosty Blue",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit No Iron Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1424923/croft-barrow-classic-fit-no-iron-dress-shirt-men.jsp",
			"productId": "1424923",
			"availableColors": ["Frosty Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1424923/croft-barrow-classic-fit-no-iron-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1424923/croft-barrow-classic-fit-no-iron-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99 - $65.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1424931_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Slim-fit Solid No Iron Point Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1424931/croft-barrow-slim-fit-solid-no-iron-point-collar-dress-shirt-men.jsp",
			"productId": "1424931",
			"availableColors": ["Studio White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1424931/croft-barrow-slim-fit-solid-no-iron-point-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1424931/croft-barrow-slim-fit-solid-no-iron-point-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1424944_True_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "True Blue",
			"productTitle": "Croft &amp; Barrow&reg; Fitted Solid No Iron Point Collar Dress Shirt",
			"prodSeoURL": "/product/prd-1424944/croft-barrow-fitted-solid-no-iron-point-collar-dress-shirt.jsp",
			"productId": "1424944",
			"availableColors": ["True Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1424944/croft-barrow-fitted-solid-no-iron-point-collar-dress-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1424944/croft-barrow-fitted-solid-no-iron-point-collar-dress-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1425021_Light_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Wide Herringbone No Iron Spread Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1425021/croft-barrow-classic-fit-wide-herringbone-no-iron-spread-collar-dress-shirt-men.jsp",
			"productId": "1425021",
			"availableColors": ["Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1425021/croft-barrow-classic-fit-wide-herringbone-no-iron-spread-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1425021/croft-barrow-classic-fit-wide-herringbone-no-iron-spread-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99 - $65.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1425032_Black?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Black",
			"productTitle": "Croft &amp; Barrow&reg; Fitted Herringbone Spread Collar No Iron Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1425032/croft-barrow-fitted-herringbone-spread-collar-no-iron-dress-shirt-men.jsp",
			"productId": "1425032",
			"availableColors": ["Black", "Navy", "White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1425032/croft-barrow-fitted-herringbone-spread-collar-no-iron-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1425032/croft-barrow-fitted-herringbone-spread-collar-no-iron-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$34.99 - $65.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1425039_Purple_Herringbone?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Purple Herringbone",
			"productTitle": "Croft &amp; Barrow&reg; Slim-Fit Herringbone Spread Collar No Iron Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1425039/croft-barrow-slim-fit-herringbone-spread-collar-no-iron-dress-shirt-men.jsp",
			"productId": "1425039",
			"availableColors": ["Purple Herringbone", "White Herringbone", "Light Blue Herringbone", "Pink Herringbone"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1425039/croft-barrow-slim-fit-herringbone-spread-collar-no-iron-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1425039/croft-barrow-slim-fit-herringbone-spread-collar-no-iron-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$65.00",
				"salePrice": "$32.99 - $34.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1425059_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Slim-Fit No Iron Button Down-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1425059/croft-barrow-slim-fit-no-iron-button-down-collar-dress-shirt-men.jsp",
			"productId": "1425059",
			"availableColors": ["Studio White"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1425059/croft-barrow-slim-fit-no-iron-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1425059/croft-barrow-slim-fit-no-iron-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$18.99 - $45.00",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1426381_Studio_White?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Studio White",
			"productTitle": "Croft &amp; Barrow&reg; Classic-Fit Solid Easy-Care Point-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1426381/croft-barrow-classic-fit-solid-easy-care-point-collar-dress-shirt-men.jsp",
			"productId": "1426381",
			"availableColors": ["Studio White", "Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1426381/croft-barrow-classic-fit-solid-easy-care-point-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1426381/croft-barrow-classic-fit-solid-easy-care-point-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$19.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1426402_Light_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "Croft &amp; Barrow&reg; Slim-Fit Solid Easy-Care Button-Down Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1426402/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-men.jsp",
			"productId": "1426402",
			"availableColors": ["Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1426402/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1426402/croft-barrow-slim-fit-solid-easy-care-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$19.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1426404_Light_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Light Blue",
			"productTitle": "Croft &amp; Barrow&reg; Fitted Solid Easy-Care Point-Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1426404/croft-barrow-fitted-solid-easy-care-point-collar-dress-shirt-men.jsp",
			"productId": "1426404",
			"availableColors": ["Light Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1426404/croft-barrow-fitted-solid-easy-care-point-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1426404/croft-barrow-fitted-solid-easy-care-point-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$45.00",
				"salePrice": "$19.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1426497_Bengal_Navy?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Bengal Navy",
			"productTitle": "Croft &amp; Barrow&reg; Striped Fitted Button-Down Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1426497/croft-barrow-striped-fitted-button-down-dress-shirt-men.jsp",
			"productId": "1426497",
			"availableColors": ["Bengal Navy"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1426497/croft-barrow-striped-fitted-button-down-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1426497/croft-barrow-striped-fitted-button-down-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1392706_Gold?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Gold",
			"productTitle": "Chaps Ontario Plaid Oxford Casual Button-Down Shirt",
			"prodSeoURL": "/product/prd-1392706/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp",
			"productId": "1392706",
			"availableColors": ["Gold"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1392706/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1392706/chaps-ontario-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1392720_Deep_Atlantic?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Deep Atlantic",
			"productTitle": "Chaps Pine Hill Plaid Oxford Casual Button-Down Shirt",
			"prodSeoURL": "/product/prd-1392720/chaps-pine-hill-plaid-oxford-casual-button-down-shirt.jsp",
			"productId": "1392720",
			"availableColors": ["Deep Atlantic"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1392720/chaps-pine-hill-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1392720/chaps-pine-hill-plaid-oxford-casual-button-down-shirt.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$50.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1812264_Slate?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Slate",
			"productTitle": "IZOD Slim-Fit Solid Twill Button-Down Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1812264/izod-slim-fit-solid-twill-button-down-collar-dress-shirt-men.jsp",
			"productId": "1812264",
			"availableColors": ["Slate"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1812264/izod-slim-fit-solid-twill-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1812264/izod-slim-fit-solid-twill-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$55.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1826192?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Blue",
			"productTitle": "Red X Flocked King of Hearts Button-Down Shirt - Men",
			"prodSeoURL": "/product/prd-1826192/red-x-flocked-king-of-hearts-button-down-shirt-men.jsp",
			"productId": "1826192",
			"availableColors": ["Blue"],
			"variations": "Size",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1826192/red-x-flocked-king-of-hearts-button-down-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1826192/red-x-flocked-king-of-hearts-button-down-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$35.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1826426_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Blue",
			"productTitle": "Gold Series Neck-Relaxer Oxford  Easy-Care Button-Down Collar Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1826426/gold-series-neck-relaxer-oxford-easy-care-button-down-collar-dress-shirt-big-tall.jsp",
			"productId": "1826426",
			"availableColors": ["Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1826426/gold-series-neck-relaxer-oxford-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1826426/gold-series-neck-relaxer-oxford-easy-care-button-down-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$30.00",
				"salePrice": "",
				"regularPriceLabel": "Original",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1732335_Aged_Brick?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Aged Brick",
			"productTitle": "Dickies Plaid Shirt - Men",
			"prodSeoURL": "/product/prd-1732335/dickies-plaid-shirt-men.jsp",
			"productId": "1732335",
			"availableColors": ["Aged Brick"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1732335/dickies-plaid-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1732335/dickies-plaid-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$38.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "Original",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1732545_Powder_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Powder Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Solid Broadcloth Point-Collar Dress Shirt - Big &amp; Tall</p>",
			"prodSeoURL": "/product/prd-1732545/croft-barrow-solid-broadcloth-point-collar-dress-shirt-big-tall.jsp",
			"productId": "1732545",
			"availableColors": ["Powder Blue"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1732545/croft-barrow-solid-broadcloth-point-collar-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1732545/croft-barrow-solid-broadcloth-point-collar-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$32.00",
				"salePrice": "$14.99",
				"regularPriceLabel": "",
				"salePriceLabel": "sale",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1733197_Estate_Blue?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Estate Blue",
			"productTitle": "<p>Croft &amp; Barrow&reg; Fitted Solid Broadcloth Point-Collar Dress Shirt - Men</p>",
			"prodSeoURL": "/product/prd-1733197/croft-barrow-fitted-solid-broadcloth-point-collar-dress-shirt-men.jsp",
			"productId": "1733197",
			"availableColors": ["Estate Blue", "Gray", "Blue Bonnet"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1733197/croft-barrow-fitted-solid-broadcloth-point-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1733197/croft-barrow-fitted-solid-broadcloth-point-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$48.00",
				"salePrice": "",
				"regularPriceLabel": "Regular",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1687443_Gray_Metro?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Gray Metro",
			"productTitle": "Apt. 9&reg; Slim-Fit Stretch Solid Dress Shirt - Big &amp; Tall",
			"prodSeoURL": "/product/prd-1687443/apt-9-slim-fit-stretch-solid-dress-shirt-big-tall.jsp",
			"productId": "1687443",
			"availableColors": ["Gray Metro"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1687443/apt-9-slim-fit-stretch-solid-dress-shirt-big-tall.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1687443/apt-9-slim-fit-stretch-solid-dress-shirt-big-tall.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}, {
			"pricing": {
				"regularPrice": "$50.00",
				"salePrice": "",
				"regularPriceLabel": "",
				"salePriceLabel": "",
				"isInvCheckReqd": false,
				"isSuppressed": false,
				"tieredPrice": "",
				"percentageOff": ""
			},
			"prodImageURL": "//media.kohlsimg.com/is/image/kohls/1803928_Sapphire?wid=240&hei=240&op_sharpen=1",
			"badges": [{
				"imageURL": "/snb/media/images/product_badges/Online_Exclusive_v1_m56577569839119755.gif",
				"altText": "Online_Exclusive.gif",
				"imageName": "Online_Exclusive.gif"
			}],
			"prodType": "product",
			"displayColor": "Sapphire",
			"productTitle": "IZOD Solid Twill Button-Down Collar Dress Shirt - Men",
			"prodSeoURL": "/product/prd-1803928/izod-solid-twill-button-down-collar-dress-shirt-men.jsp",
			"productId": "1803928",
			"availableColors": ["Sapphire", "Black", "Cornflower Blue", "Tarragon", "Crimson"],
			"variations": "SizeAndColor",
			"altImageUrl": null,
			"ratings": {
				"reviewTitle": " reviews",
				"reviewURL": "/product/prd-1803928/izod-solid-twill-button-down-collar-dress-shirt-men.jsp?clickAction=slreviewCount&isRatings=true#rating-content",
				"ratingCount": null,
				"reviewCount": null,
				"ratingsTitle": "Ratings : null of 5.0",
				"ratingsURL": "/product/prd-1803928/izod-solid-twill-button-down-collar-dress-shirt-men.jsp?clickAction=slrating&isRatings=true#rating-content"
			}
		}],
		"tabInfo": {
			"allProducts": {
				"count": 1729,
				"isSelected": true,
				"tabName": "All Products",
				"URL": ""
			}
		}
	},
	"sorting": {
		"sortOptions": [{
			"name": "Featured",
			"URL": "/search.jsp?N=0&search=shirts&S=1"
		}, {
			"name": "New Arrivals",
			"URL": "/search.jsp?N=0&search=shirts&S=2"
		}, {
			"name": "Best Sellers",
			"URL": "/search.jsp?N=0&search=shirts&S=3"
		}, {
			"name": "Price Low-High",
			"URL": "/search.jsp?N=0&search=shirts&S=4"
		}, {
			"name": "Price High-Low",
			"URL": "/search.jsp?N=0&search=shirts&S=5"
		}, {
			"name": "Highest Rated",
			"URL": "/search.jsp?N=0&search=shirts&S=6"
		}, {
			"name": "Percent Off",
			"URL": "/search.jsp?N=0&search=shirts&S=7"
		}],
		"name": "Sort By :",
		"defaultSortOption": "Featured"
	},
	"itemsPerPage": {
		"label": "Show",
		"defaultOption": 60,
		"options": ["30", "60", "90", "120"]
	},
	"bopus": {
		"pmpBopusEncEnabled": true,
		"fisSearchUrl": "/rest/bean/com/kohls/commerce/omnichannel/findinstore/AllStoresAvailabilitySearch?atg-rest-output=json&atg-rest-depth=1",
		"goopleApiURL": "//maps.googleapis.com/maps/api/js?client=gme-kohlsdepartmentstores&v=3.15&libraries=places&sensor=false"
	},
	"pageMaxPrice": {
		"minPrice": 71,
		"maxPrice": 355
	},
	"staticContents": {
		"swatchUrlParam": "wid=20&hei=20",
		"bopusLocationNotFoundMsg": "No stores found within 50 miles. Please try another location.",
		"bopusLoadMoreStoresTxt": "Load More Stores",
		"imageUrlParam": "wid=240&hei=240&op_sharpen=1",
		"imageBaseUrlList": ["https://media.kohlsimg.com/is/image/kohls", "https://media1.kohlsimg.com/is/image/kohls", "https://media2.kohlsimg.com/is/image/kohls"],
		"noLongerAvailableMessage": "We're sorry, this item is discontinued",
		"soldAndShippedBy": "Sold & Shipped by",
		"productOOSMessage": "We're sorry, this item is currently unavailable",
		"GWP_Get_Price": "FREE",
		"marketplaceBrowseShopContentBoxMsg": "<div class=\"messageBoxFirst messageBox\"> By partnering with other sellers, we can provide more unique online-only options than ever before.</div> \r <div class=\"messageBoxSecond messageBox\"><h3>ONE CHECKOUT</h3> Add items to your bag and check out conveniently here on Kohls.com.</div> \r <div class=\"messageBoxThird messageBox\"><h3>RESTRICTIONS</h3> You can�t earn or redeem Kohl�s Cash or Yes2You Rewards on products sold by Wayfair. Coupons and other discounts do not apply to products sold by Wayfair.</div> \r <div class=\"messageBoxFourth messageBox\"><h3>SHIPPING & RETURNS</h3> Wayfair ships these items. To return, simply contact Wayfair. Items cannot be returned at Kohls.com or Kohl�s stores.</div>",
		"PWP_Get_Price_Text": "Special Savings with Purchase",
		"supressedStaticContent": "FOR PRICE, ADD TO BAG",
		"bopusInvalidInputErrorMsg": "Please enter a valid ZIP code or City, State, separated by a comma.",
		"gwpTitle": "Gift with Purchase",
		"pwpTitle": "Special Savings Item",
		"altImageNavDelay": "200",
		"didYouMeanSuggestions": "Did you mean:",
		"GWP_Get_Price_Text": "Your Price",
		"GIVServiceUnavailable": "Service is currently unavailable. Please try again later"
	},
	"thirdParty": {
		"query": "shirts",
		"dfp": {
			"path": "/17763952/ROS",
			"adParameterMap": [],
			"pgtype": "search results"
		},
		"adsense": {
			"pageOptions": {
				"linkTarget": "_blank",
				"pubId": "kohls-search",
				"hl": "en",
				"domainLinkAboveDescription": true,
				"detailedAttribution": true,
				"attributionText": "",
				"adPage": 1,
				"channel": "",
				"adsResponseCallback": "getNumberOfAds",
				"adtest": "off",
				"titleBold": true,
				"plusOnes": false,
				"sellerRatings": true,
				"siteLinks": true,
				"adLayout": "sellerFirst"
			},
			"adblock": {
				"showBottomRail": true,
				"showSideRail": true,
				"showSideRail2": false,
				"sideRail2minProductsRequired": 29,
				"fontFamily": false,
				"fontSizeTitle": "12px",
				"fontSizeDescription": "12px",
				"fontSizeDomainLink": "12px",
				"fontSizePlusOnes": "12px",
				"colorTitleLink": "#000000",
				"colorText": 0,
				"colorDomainLink": "8f887f",
				"colorBackground": "FFFFFF",
				"colorBorder": "#F0EFED",
				"borderSelections": "right,left,bottom",
				"bottom_adblock": {
					"container": "adcontainer1",
					"width": 760,
					"number": 8,
					"lines": 2,
					"colorPlusOnes": "#666666",
					"noTitleUnderline": false,
					"detailedAttribution": true,
					"longerHeadlines": false
				},
				"side_adblock": {
					"container2": "adcontainer2",
					"container3": "adcontainer3",
					"width": 178,
					"number": 8,
					"lines": 3,
					"noTitleUnderline": false,
					"detailedAttribution": false,
					"longerHeadlines": false
				}
			}
		},
		"afsh": {
			"afsh_pageOptions": {
				"pubId": "partner-vert-pla-kohls-srp",
				"channel": "",
				"adsafe": "high",
				"adtest": "off",
				"hl": "en",
				"theme": "walleye",
				"priceCurrency": "USD",
				"linkTarget": "_blank"
			},
			"afsh_adblock": {
				"container": "afshcontainer",
				"width": "760",
				"height": "265",
				"adLoadedCallback": "hideContainer"
			}
		},
		"richrelevance": {
			"apiKey": "648c894ab44bc04a",
			"rrBbaseUrl": "//recs.richrelevance.com/rrserver/",
			"doubleForwardSlash": "//",
			"horizontalScroller": "search_page.new_horizontal",
			"newHorizontalScroller": "search_page.new_horizontal",
			"isNewPMPSearch": true,
			"richPlacement": "search_page.new_horizontal",
			"searchTerm": "shirts",
			"productIdMap": ["825463", "689516", "1225471", "1151180", "387673", "1127504", "1438041", "1098383", "1437219", "663275", "1177683", "1436741", "1170622", "1437217", "1129287", "1170625", "1170626", "1177088", "1278103", "1278131", "1276544", "1263725", "1263950", "1480694", "1512324", "1522851", "1600636", "1524590", "1432892", "1436737", "1436806", "1350994", "1437218", "1411777", "1438132", "1419214", "1419277", "1424768", "1424917", "1424923", "1424931", "1424944", "1425021", "1425032", "1425039", "1425059", "1426381", "1426402", "1426404", "1426497", "1392706", "1392720", "1812264", "1826192", "1826426", "1732335", "1732545", "1733197", "1687443", "1803928"],
			"productId": "1803928"
		},
		"br_data": {
			"acct_id": 5117,
			"ptype": "search results"
		},
		"brighttag": {
			"brightTagURL": "//s.btstatic.com/tag.js",
			"brightTagSiteId": "4DPyaxM",
			"pageData": {
				"pmpDetails": {
					"departmentName": "N/A",
					"categoryName": "N/A",
					"subcategoryName": "N/A",
					"findingName": "search",
					"keywords": "shirts",
					"pageFilter": "N/A",
					"genderValues": "No Gender",
					"pageProductIDs": "825463,689516,1225471,1151180,387673,1127504,1438041,1098383,1437219,663275,1177683,1436741,1170622,1437217,1129287,1170625,1170626,1177088,1278103,1278131,1276544,1263725,1263950,1480694,1512324,1522851,1600636,1524590,1432892,1436737,1436806,1350994,1437218,1411777,1438132,1419214,1419277,1424768,1424917,1424923,1424931,1424944,1425021,1425032,1425039,1425059,1426381,1426402,1426404,1426497,1392706,1392720,1812264,1826192,1826426,1732335,1732545,1733197,1687443,1803928",
					"isHooklogicEnabled": true,
					"pageType": "search results",
					"pageView": "grid"
				}
			}
		}
	},
	"totalRecord": "1729"
};
module.exports = pmpSearchJsonData;